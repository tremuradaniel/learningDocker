package com.example.spring_maven_docker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMavenDockerApplicationTests {

	@Test
	void contextLoads() {
	}

}
